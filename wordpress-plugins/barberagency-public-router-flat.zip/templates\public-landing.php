<?php
if (!defined('ABSPATH')) {
    exit;
}

$page = $GLOBALS['ba_public_landing_page'] ?? null;

if (!$page instanceof WP_Post) {
    status_header(404);
    nocache_headers();
    get_template_part('404');
    return;
}

get_header();
?>
<main id="barberagency-public-landing">
    <?php
    if (
        did_action('elementor/loaded') &&
        class_exists('\Elementor\Plugin')
    ) {
        echo \Elementor\Plugin::instance()
            ->frontend
            ->get_builder_content_for_display($page->ID, true);
    } else {
        echo apply_filters('the_content', $page->post_content);
    }
    ?>
</main>
<?php
get_footer();
